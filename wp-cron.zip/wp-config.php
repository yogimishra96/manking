<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wps');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'L|k/ojtT+Y<j|(!rwfLiX{cLS5B?414{-B5FUmWKW^$/u:_m~a+,5Ybq8Y4f<UTX');
define('SECURE_AUTH_KEY',  '||!;~:3B.oh?pZMehlZ0>R*vvTxd`sGNJ.F OcW8Fq[q#=|dVcQdp6a(R1$;6#+e');
define('LOGGED_IN_KEY',    '4G~Ews;plP:E-h!fPKlE1hyK}0e%n2_:_|e*JvUQvXG%urM19J}@(4cI-/#H.t|!');
define('NONCE_KEY',        'Zx[j=lW(z$-?ku`32>Z#olvrCm,! NKV$ob0kH }F=w14<uK(mpXP[dXG?qEsrLv');
define('AUTH_SALT',        'Z)_xFbwm*!T=^US3+EzUM`2wmyxf!M<]hf @A4JT{w N&e:))rC2<WwCoY@Tz*%Y');
define('SECURE_AUTH_SALT', '@$@mNWu:n{K<^bJ4>K(m9JpZoz(J`GfWiEz3,iRnLm`|`!w0lR1B$uN].7V.#y]z');
define('LOGGED_IN_SALT',   '>.XYbvY#lJgBzCVWQO5#zs1}ld^A#<<I87 iPd>A[6~Ma5&5~f#agQM,zfMYlC_T');
define('NONCE_SALT',       '<F>#+ON,S?~-InuICA_J<;U.Th;MGCAa,BhFU/r8J1$&(,%S{s*Xcom:Ek88EqaW');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
